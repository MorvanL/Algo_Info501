#ifndef __arete__
#define __arete__

typedef struct{
	int valeur;
	int s1;
	int s2;
}arete;

arete* creerArete (int, int, int);

#endif
