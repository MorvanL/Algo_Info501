int parent(int );
int gauche (int );
int droite (int );


